# OS Lab 2 // May, Taylor - ID: 101516431

## Introduction

> This is based on the requirements set in the lab2 pdf

> This program emulates a CPU scheduler.

## Features

> This program features three different scheduling algorithms

> First Come First Serve(FCFS) is arg 0

> Shortest Remaining Task First(SRTF) is arg 1

> Round Robin (RR) is arg 2, and requires a quantum when it is called.

> The program can accept as many processes as are provided given that they are in the proper format
	eg: 1	2	5
		2	5	3